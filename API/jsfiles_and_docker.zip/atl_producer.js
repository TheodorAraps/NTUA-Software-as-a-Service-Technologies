const Kafka = require('node-rdkafka');
const fs = require("fs");
const eventType = require('./eventType.js');

// DIRECTORY OF CSV FILES (FOR ATL)
const directoryPath = '../ATL_final'

// AREANAME PER PARTITION ENUMERATION
const aeraName_partition = {
    'AL CTY': 0,
    'AT CTY': 1,
    'BY CTY': 2,
    'BE CTY': 3,
    'BA CTY': 4,
    'BG CTY': 5,
    'HR CTY': 6,
    'CY CTY': 7,
    'CZ CTY': 8,
    'DK CTY': 9,
    'EE CTY': 10,
    'FI CTY': 11,
    'FR CTY': 12,
    'GE CTY': 13,
    'DE CTY': 14,
    'GR CTY': 15,
    'HU CTY': 16,
    'IE CTY': 17,
    'IT CTY': 18,
    'LV CTY': 19,
    'LT CTY': 20,
    'LU CTY': 21,
    'MT CTY': 22,
    'ME CTY': 23,
    'NL CTY': 24,
    'MK CTY': 25,
    'NO CTY': 26,
    'PL CTY': 27,
    'PT CTY': 28,
    'MD CTY': 29,
    'RO CTY': 30,
    'RS CTY': 31,
    'SK CTY': 32,
    'SI CTY': 33,
    'ES CTY': 34,
    'SE CTY': 35,
    'CH CTY': 36,
    'TR CTY': 37,
    'UA CTY': 38,
    'UK CTY': 39,
    'Russian Federation': 40,
    'Armenia': 41,
    'Azerbaijan': 42,
    'AZ CTY': 43,
    'RU CTY': 44,
    'XK CTY': 45,
    'AM CTY': 46
    }

var producer = new Kafka.Producer({
    'metadata.broker.list': 'localhost:19092, localhost:29092, localhost:39092',
    'dr_cb': true
});

function sleep(time, callback) {
    var stop = new Date().getTime();
    while(new Date().getTime() < stop + time) {
        ;
    }
    callback();
}

// Connect to the broker manually
producer.connect();

// Wait for the ready event before proceeding
producer.on('ready', function() {
    try {
        fs.readdir(directoryPath, function (err, files) {
            if (err) {
                return console.log('Unable to scan directory: ' + err);
            } 

            // PARSE ALL FILES IN THE DIRECTORY
            files.forEach(function (file) {
                
                //SENDS DATA EVERY 10 SECS
                sleep(5000, function() {
                    // READ CSV INTO STRING
                    var data = fs.readFileSync(directoryPath + "/" + file, "utf8");
                    
                    // STRING TO ARRAY
                    data = data.split("\n"); // SPLIT ROWS
                    for (let i in data) { // SPLIT COLUMNS
                        data[i] = data[i].split("\t");
                        if (data[i][3] == 'CTY') {  
                            const partition = aeraName_partition[data[i][4]];
                            const dateTime = data[i][0];
                            const TotalLoadValue = data[i][6];
                            const event = { dateTime, TotalLoadValue };
                            
                            let key = "key-"+i;
                            producer.produce(
                                // Topic to send the message to
                                'atl',
                                // optionally we can manually specify a partition for the message
                                // this defaults to -1 - which will use librdkafka's default partitioner (consistent random for keyed messages, random for unkeyed messages)
                                partition,
                                // Message to send. Must be a buffer
                                eventType.toBuffer(event),
                                // for keyed messages, we also specify the key - note that this field is optional
                                key,
                                // you can send a timestamp here. If your broker version supports it,
                                // it will get added. Otherwise, we default to 0
                                Date.now(),
                                // you can send an opaque token here, which gets passed along
                                // to your delivery reports
                            );
                            // We must either call .poll() manually after sending messages
                            // or set the producer to poll on an interval (.setPollInterval).
                            // Without this, we do not get delivery events and the queue
                            // will eventually fill up.
                            producer.poll();
                        }
                    }
                }); 
            });
        });
        producer.disconnect();

    } catch (err) {
        console.error('A problem occurred when sending our message');
        console.error(err);
    }
});

// Any errors we encounter, including connection errors
producer.on('event.error', function(err) {
    console.error('Error from producer');
    console.error(err);
})

