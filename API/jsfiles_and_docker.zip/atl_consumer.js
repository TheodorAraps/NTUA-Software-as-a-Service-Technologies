const Kafka = require('node-rdkafka');
const eventType = require('./eventType.js');
const express = require('express');
const app = express()
const mysql = require('mysql');

//this is needed for frontend
const cors = require('cors');


const country_partition = {
    0: 'AL CTY',
    1: 'AT CTY',
    2: 'BY CTY',
    3: 'BE CTY',
    4: 'BA CTY',
    5: 'BG CTY',
    6: 'HR CTY',
    7: 'CY CTY',
    8: 'CZ CTY',
    9: 'DK CTY',
    10: 'EE CTY',
    11: 'FI CTY',
    12: 'FR CTY',
    13: 'GE CTY',
    14: 'DE CTY',
    15: 'GR CTY',
    16: 'HU CTY',
    17: 'IE CTY',
    18: 'IT CTY',
    19: 'LV CTY',
    20: 'LT CTY',
    21: 'LU CTY',
    22: 'MT CTY',
    23: 'ME CTY',
    24: 'NL CTY',
    25: 'MK CTY',
    26: 'NO CTY',
    27: 'PL CTY',
    28: 'PT CTY',
    29: 'MD CTY',
    30: 'RO CTY',
    31: 'RS CTY',
    32: 'SK CTY',
    33: 'SI CTY',
    34: 'ES CTY',
    35: 'SE CTY',
    36: 'CH CTY',
    37: 'TR CTY',
    38: 'UA CTY',
    39: 'UK CTY',
    40: 'Russian Federation',
    41: 'Armenia',
    42: 'Azerbaijan',
    43: 'AZ CTY',
    44: 'RU CTY',
    45: 'XK CTY',
    46: 'AM CTY'
}


//localhost's port
const port = 9103;

//Initialise a variable having our database's informations (it runs locally using xampp)
let con = mysql.createConnection({
host: 'localhost',
user: 'root',
password: 'mysqlpswrd',
database: 'saas22atl'
});

//Initialise cors for frontend
let corsOptions = {
    origin: 'http://localhost:3000',
    optionsSuccessStatus: 200, // For legacy browser support
    methods: "GET"
}

// app.use(cors(corsOptions));

//Initialise server
app.listen(port, () =>
    console.log('Server is alive on http://localhost:' + port)
)

//Connect with the database 
con.connect(function(err) {
    if (err) throw err;
    console.log("Connected to database!");
});

let consumer = new Kafka.KafkaConsumer({
  'group.id': 'kafka',
  'metadata.broker.list': 'localhost:19092, localhost:29092, localhost:39092',
}, {});

consumer.connect();

let word3 = undefined;
let word4 = undefined;
let word5 = undefined;

consumer.on('ready', function() {
  console.log('consumer ready..')
  consumer.subscribe(['atl']);
  consumer.consume();
}).on('data', function(data) {
    word3 = country_partition[data.partition.toString()];                   // AreaName from partition that the message came
    word4 = (JSON.parse(eventType.fromBuffer(data.value))['dateTime']);               // Datetime to string
    word5 = parseInt(JSON.parse(eventType.fromBuffer(data.value))['TotalLoadValue']); // Actual Total Load from string to int
    let sqlquery = 'REPLACE INTO `atl data load` (AreaName, DateTime, TotalLoadValue) VALUES ( ? , ? , ? )';
    const words = [word3, word4, word5];
    con.query(sqlquery, words, function (err, result) {
        if (err) throw err;
    });
  console.log(`received message: areaName: ${word3}, ${eventType.fromBuffer(data.value)} from partition: ${parseInt(data.partition.toString())}`);
});

const abbrv = {
    "Albania": "AL CTY",
    "Austria": "AT CTY",
    "Belarus": "BY CTY",
    "Belgium": "BE CTY",
    "Bosnia Herzegovina": "BA CTY",
    "Bulgaria": "BG CTY",
    "Croatia": "HR CTY",
    "Cyprus": "CY CTY",
    "Czech Republic": "CZ CTY",
    "Denmark": "DK CTY",
    "Estonia": "EE CTY",
    "Finland": "FI CTY",
    "France": "FR CTY",
    "Georgia": "GE CTY",
    "Germany": "DE CTY",
    "Greece": "GR CTY",
    "Hungary": "HU CTY",
    "Ireland": "IE CTY",
    "Italy": "IT CTY",
    "Latvia": "LV CTY",
    "Lithuania": "LT CTY",
    "Luxembourg": "LU CTY",
    "Malta": "MT CTY",
    "Montenegro": "ME CTY",
    "Netherlands": "NL CTY",
    "North Macedonia": "MK CTY",
    "Norway": "NO CTY",
    "Poland": "PL CTY",
    "Portugal": "PT CTY",
    "Republic of Moldova": "MD CTY",
    "Romania": "RO CTY",
    "Serbia": "RS CTY",
    "Slovakia": "SK CTY",
    "Slovenia": "SI CTY",
    "Spain": "ES CTY",
    "Sweden": "SE CTY",
    "Switzerland": "CH CTY",
    "Turkey": "TR CTY",
    "Ukraine": "UA CTY",
    "United Kingdom": "UK CTY",
    "Russia Federation": "Russian Federation",
    "Armenia Main": "Armenia",
    "Azerbaijan Main": "Azerbaijan",
    "Azerbaijan": "AZ CTY",
    "Russia": "RU CTY",
    "Kosovo": "XK CTY",
    "Armenia": "AM CTY"
}

